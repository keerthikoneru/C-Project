﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutoring_System.BLL
{
    class Syllabus
    {
        public DataTable FillSyllabusContents(String fn_syllabus)
        {
            StreamReader StreamReader = new StreamReader(fn_syllabus);
            DataTable dtTopics = null;
            int RowCount = 0;
            string[] ColumnNames = null;
            string[] StreamDataValues = null;
            while (!StreamReader.EndOfStream)
            {
                String StreamRowData = StreamReader.ReadLine().Trim();
                if (StreamRowData.Length > 0)
                {
                    StreamDataValues = StreamRowData.Split(',');
                    if (RowCount == 0)
                    {
                        RowCount = 1;
                        ColumnNames = StreamRowData.Split(',');
                        dtTopics = new DataTable();
                        foreach (string csvcolumn in ColumnNames)
                        {
                            DataColumn oDataColumn = new DataColumn(csvcolumn, typeof(string));
                            oDataColumn.DefaultValue = string.Empty;
                            dtTopics.Columns.Add(oDataColumn);
                        }
                    }
                    else
                    {            
                        DataRow oDataRow = dtTopics.NewRow();
                        for (int i = 0; i < ColumnNames.Length; i++)
                        {
                            oDataRow[ColumnNames[i]] = StreamDataValues[i] == null ? string.Empty : StreamDataValues[i].ToString();
                        }       
                        dtTopics.Rows.Add(oDataRow);
                    }
                }
            }
            StreamReader.Close();
            StreamReader.Dispose();
            return dtTopics;
        }
        //public DataTable FillSyllabusContents(String fn_syllabus)
        //{
        //    DataTable dt_syllabus = new DataTable();
        //    dt_syllabus.Columns.Add("ChapterID");//for collapsible menu
        //    dt_syllabus.Columns.Add("Topic");
        //    dt_syllabus.Columns.Add("Path");
        //    dt_syllabus.Columns.Add("Progress");
        //    dt_syllabus.Columns.Add("VideoLinkPath");   // for adding video
        //    dt_syllabus.Columns.Add("Test"); // for adding test module
        //    dt_syllabus.Columns.Add("TestPath"); // for adding test module
        //    dt_syllabus.Columns.Add("TestProgress");//for progress of test module
        //    dt_syllabus.Columns.Add("Score");
        //    dt_syllabus.Columns.Add("Totalmarks");
        //    dt_syllabus.Columns.Add("Randqs");
            
        //    StreamReader streamReader = null;
        //    string filepath = fn_syllabus;
        //    try
        //    {
        //        streamReader= new StreamReader(filepath);
        //        string[] totaltopics = new string[File.ReadAllLines(filepath).Length];
        //        while (!streamReader.EndOfStream)
        //        {
        //            totaltopics = streamReader.ReadLine().Split(',');
        //            //int count = Convert.ToInt32(totaltopics.Count);
        //            DataRow Row = dt_syllabus.NewRow();
        //            for (int i = 0; i <= 10; i++)
        //                Row[i] = totaltopics[i];
        //            dt_syllabus.Rows.Add(Row);
        //        }
        //        return dt_syllabus;
        //    }
        //    catch (Exception ex)
        //    {
        //        return dt_syllabus = null;
        //    }
        //    finally
        //    {
        //        if (streamReader != null)
        //            streamReader.Close();
        //    }
        //}
        public DataTable FillMainchapters(String fn_Chapters)
        {
            DataTable dt_chapters = new DataTable();
            dt_chapters.Columns.Add("ChapterID");
            dt_chapters.Columns.Add("Chapter");
            StreamReader streamReader = null;
            string filepath = fn_Chapters;
            try
            {
                streamReader = new StreamReader(filepath);
                string[] totaltopics = new string[File.ReadAllLines(filepath).Length];
                while (!streamReader.EndOfStream)
                {
                    totaltopics = streamReader.ReadLine().Split(',');
                    //int count = Convert.ToInt32(totaltopics.Count);
                    DataRow Row = dt_chapters.NewRow();
                    for (int i = 0; i <= 1; i++)
                        Row[i] = totaltopics[i];
                    dt_chapters.Rows.Add(Row);
                }
                return dt_chapters;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return dt_chapters = null;
            }
            finally
            {
                if (streamReader != null)
                    streamReader.Close();
            }
        }
    }
}
