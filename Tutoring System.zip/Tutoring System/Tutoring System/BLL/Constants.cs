﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Configuration.dll;

namespace Tutoring_System.BLL
{
    class Constants
    {
        public string fn_Syllabus = System.Configuration.ConfigurationManager.AppSettings["DB"];
        public string fn_Chapters = System.Configuration.ConfigurationManager.AppSettings["DBChapters"];
        public string fn_Ppt = null; //= ConfigurationSettings.AppSettings["PPTX"];
        public string fn_Shell = System.Configuration.ConfigurationManager.AppSettings["SHELL"];
        public string destFileName = System.Configuration.ConfigurationManager.AppSettings["FILEPATH"];
        public string fn_Video = null; // for adding video
        public string fn_Testpath = null; // for adding test module
        public string randqs = "0";
        public string selectedtopic = null; //for updating score in database
        public string fn_Pdf = null;
        public string fn_Text = null;
        public string fn_Word = null;
    }
}
