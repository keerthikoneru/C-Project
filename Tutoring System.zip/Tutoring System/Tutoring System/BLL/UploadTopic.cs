﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tutoring_System.BLL;

namespace Tutoring_System.BLL
{
    class UploadTopic
    {
        public bool UploadTopics(String pptfileName,String pdffileName,String textfileName,String wordfileName, String quizfilename, String PPTpath,String PDFpath,String TEXTpath,String WORDpath, String quizpath, String chapter,String topic, String videoURL)
        {
            try
            {
                Constants objConstants = new Constants();
                string destFileName = objConstants.destFileName;
                var csvtopic = new StringBuilder();
                var csvchapter = new StringBuilder();
                Syllabus objSyllabus = new Syllabus();
                string pptfile = ""; string pdffile = ""; string textfile = ""; string wordfile = "";
                int chapterid = Convert.ToInt32(chapter.ToCharArray()[0].ToString());
                DataTable dt_Chapters = objSyllabus.FillMainchapters(objConstants.fn_Chapters);
                bool chexist = dt_Chapters.AsEnumerable().Any(p => chapterid.ToString() == p.Field<string>("ChapterID"));
                if (chexist == false)
                {
                    var newchapter = string.Format("{0},{1}{2}", chapterid, chapter, Environment.NewLine);
                    csvchapter.Append(newchapter);
                    File.AppendAllText(objConstants.fn_Chapters, csvchapter.ToString());
                }
                DataTable dt_Syllabus = objSyllabus.FillSyllabusContents(objConstants.fn_Syllabus);
                int TopicID = dt_Syllabus.Rows.Count + 1;
                int Testnumber = dt_Syllabus.AsEnumerable().Where(p => p.Field<string>("ChapterID") == chapterid.ToString()).ToList().Count+1;
                if (pptfileName != "")
                {
                    pptfile = destFileName + pptfileName;
                    File.Copy(PPTpath, destFileName + pptfileName, true);
                }
                if (pdffileName != "")
                {
                    pdffile = destFileName + pdffileName;
                    File.Copy(PDFpath, destFileName + pdffileName, true);
                }
                if (textfileName != "")
                {
                    textfile = destFileName + textfileName;
                    File.Copy(TEXTpath, destFileName + textfileName, true);
                }
                if (wordfileName != "")
                {
                    wordfile = destFileName + wordfileName;
                    File.Copy(WORDpath, destFileName + wordfileName, true);
                }
                string progress = "N";
                string videopath = videoURL;//for adding video
                string test = "Test " + Testnumber.ToString(); //for adding test module
                string testpath = destFileName + quizfilename; //for adding test module
                string testprogress = "N";
                int testscore = 0;
                int totalmarks = 0;
                string randqs = "0";
                var newLine = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}{15}", chapterid, TopicID, topic, pptfile,pdffile,textfile,wordfile, progress, videopath, test, testpath, testprogress, testscore, totalmarks, randqs, Environment.NewLine);
                csvtopic.Append(newLine);
                File.AppendAllText(objConstants.fn_Syllabus, csvtopic.ToString());
                File.Copy(quizpath, destFileName + quizfilename, true);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }
    }
}
