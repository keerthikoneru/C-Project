﻿using Tutoring_System.UserInterface;
using System.Windows.Forms;


namespace Tutoring_System
{
    /// <summary>
    /// This is the Form Controller  
    /// Implemented by Trung Dang on 03/17/2015 
    /// </summary>
    
    class FormController
    {
        private static iBaTs_TutoringSystem formMain;
        private static UploadNewTopic formUpload;
        private static Test formTest;
        private static string testtopic = "";
        private static string testpath = ""; 
        private static string randqs = ""; 
        
      
        public static void InitForms()
        {
            formMain = new iBaTs_TutoringSystem();
            formUpload = new UploadNewTopic();
            formTest = new Test(testtopic, testpath, randqs);

           

            formMain.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FormClosing);
            formUpload.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FormClosing);
            formTest.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FormClosing);
            
        }

        static void FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            Application.Exit();
        }

        public static void ShowForm(string formCode)
        {
            switch (formCode)
            {
                case "Home":
                    {
                        HideAll();
                        formMain.Show();
                        formMain.Refresh();
                        break;
                    }
                case "Upload":
                    {
                        HideAll();
                        formUpload.Show();
                        formUpload.Refresh();
                        break;
                    }
                case "Test":
                    {
                        HideAll();
                        formTest.Show();
                        formTest.Refresh();
                        break;
                    }
                default:
                    return;
            }
        }

        private static void HideAll()
        {
            //formMain.Hide();
            //formUpload.Hide();
        }
    }
    }


