﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tutoring_System.BLL
{
    class Progress
    {
        public void updateforprogress(string file, DataTable dt_syllabus)
        {
            /*updating CSV to obatin the count in order to calculate progress*/
            StreamWriter sw = new StreamWriter(file, false);
            int j = 0;
            foreach (DataColumn c in dt_syllabus.Rows[0].Table.Columns)
            {
                    sw.Write(c.ColumnName.ToString());
                    if (j < dt_syllabus.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                    j++;
            }
            sw.Write(sw.NewLine);
            foreach (DataRow row in dt_syllabus.Rows)
            {
                for (int i = 0; i < dt_syllabus.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(row[i]))
                    {
                        string value = row[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(row[i].ToString());
                        }
                    }
                    if (i < dt_syllabus.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
            /*updating CSV to obatin the count in order to calculate progress*/
        }
        public void updatescore(string file, double score, double totalmarks, string selectedtopic, string randqs)
        {
            Syllabus objSyllabus = new Syllabus();
            DataTable dt_syllabus = objSyllabus.FillSyllabusContents(file);
            try
            {
                foreach (DataRow dr in dt_syllabus.Rows)
                {
                    if (selectedtopic == dr["Topic"].ToString())
                    {
                        dr["Score"] = score;
                        dr["Totalmarks"] = totalmarks;
                        dr["Progress"] = "Y";
                        dr["TestProgress"] = "Y";
                        dr["Randqs"] = randqs;
                        updateforprogress(file, dt_syllabus);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                objSyllabus = null;
                dt_syllabus.Dispose();
            }
        }
    }
}
