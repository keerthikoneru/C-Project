﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tutoring_System.BLL;

namespace Tutoring_System.UserInterface
{
    public partial class Test : Form
    {
        private string testtopicname="";
        private string testpath = "";
        private string randqs = "";
        public int count = 1;
        public int k = 0;
        public System.Data.DataTable dtTest;
        public int score = 0;
        Constants objConstants = new Constants();
        
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern IntPtr FindWindow(string className, string windowtext);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
       
        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, int uFlags);

        public static string XMLPath;
        private const int SWP_NOZORDER = 0x0004;
        private const int SWP_NOACTIVATE = 0x0010;
        private const int GWL_STYLE = -16;
        private const int WS_CAPTION = 0x00C00000;
        private const int WS_THICKFRAME = 0x00040000;

        public Test(string testtopic, string path, string qs)
        {
            InitializeComponent();
            testtopicname = testtopic;
            testpath = path;
            randqs = qs;
        }

        private void OpenBash()
        {
            Process shell = new Process();
            try
            {
                shell.StartInfo.FileName = objConstants.fn_Shell;
                shell.StartInfo.Arguments = "--login -i";
                shell.Start();
                System.Threading.Thread.Sleep(100);
                SetParent(shell.MainWindowHandle, this.splitContainer2.Panel1.Handle);
                SetWindowPos(shell.MainWindowHandle, IntPtr.Zero, 0, 0, (int)this.splitContainer2.Panel1.ClientSize.Width, (int)this.splitContainer2.Panel1.ClientSize.Height, SWP_NOZORDER | SWP_NOACTIVATE);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                shell.Dispose();
            }
        }
        private void Test_Load(object sender, EventArgs e)
        {
            btnTest.Text = "Start Test";
            btnSubmit.Text = "Submit";
            lblTutoringSystem.Text = "Test on " + testtopicname;
            OpenBash();
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            lnklblHome.Enabled = false;
            if (rbA.Checked != false || rbB.Checked != false || rbC.Checked != false || rbD.Checked != false)
            {
                lblAnswer.Visible = lblAnsopt.Visible = true;
                lblAnsopt.Text = " " + dtTest.Rows[k - 1]["correct"].ToString();
                if (rbA.Checked == true && dtTest.Rows[k - 1]["correct"].ToString() == "A")
                {
                    score++;
                    lblAnsopt.ForeColor = System.Drawing.Color.Green;
                }
                else if (rbB.Checked == true && dtTest.Rows[k - 1]["correct"].ToString() == "B")
                {
                    score++;
                    lblAnsopt.ForeColor = System.Drawing.Color.Green;
                }
                else if (rbC.Checked == true && dtTest.Rows[k - 1]["correct"].ToString() == "C")
                {
                    score++;
                    lblAnsopt.ForeColor = System.Drawing.Color.Green;
                }
                else if (rbD.Checked == true && dtTest.Rows[k - 1]["correct"].ToString() == "D")
                {
                    score++;
                    lblAnsopt.ForeColor = System.Drawing.Color.Green;
                }
                else
                    lblAnsopt.ForeColor = System.Drawing.Color.Red;

                btnSubmit.Visible = false;
                btnTest.Visible = true;
                btnTest.Text = "Next";
                count++;
                if (count > dtTest.Rows.Count)
                    btnTest.Text = "Exit";
            }
            else
            {
                if (btnSubmit.Text == "Go to Home Page")
                {
                    btnSubmit.Visible = false;
                    lblTutoringSystem.Text = "iBaTs Tutoring System";
                    this.Hide();
                    FormController.ShowForm("Home");
                }
                else
                {
                    MessageBox.Show("Please select any one of the options");
                }
            }
        }
        private void btnTest_Click(object sender, EventArgs e)
        {
            lnklblHome.Enabled = false;
            DataSet dsTest = new System.Data.DataSet("XmlData");
            Constants objConstants = new Constants();
            Progress objProgress = new Progress();
            try
            {
                dsTest.ReadXml(testpath);
                dtTest = dsTest.Tables[0];
                if (dtTest != null)
                {
                    if (count >= 1 && count <= dtTest.Rows.Count)
                    {
                        if (btnTest.Text == "Start the Test")
                        {
                            score = 0;
                            objProgress.updatescore(objConstants.fn_Syllabus, 0, dtTest.Rows.Count, testtopicname, randqs);
                        }
                        lblTutoringSystem.Visible = lblAnswer.Visible = lblAnsopt.Visible = false;
                        lblOptA.Visible = lblOptB.Visible = lblOptC.Visible = lblOptD.Visible = lblQuesNo.Visible =
                            lblQuestion.Visible = rbA.Visible = rbB.Visible = rbC.Visible = rbD.Visible = true;
                        Random rand = new Random();
                        k = rand.Next(1, dtTest.Rows.Count);
                        if (randqs != "0")
                        {
                            string[] qs = randqs.Split(';');
                            if (qs.Length - 1 != dtTest.Rows.Count)
                            {
                                for (int j = 1; j < qs.Length; j++)
                                {
                                    if (k.ToString() == qs[j])
                                    {
                                        k = rand.Next(1, dtTest.Rows.Count + 1);
                                        j = 0;
                                    }
                                }
                            }
                            else
                                randqs = "0";
                        }
                        if (dtTest.Rows[k - 1]["QNo"].ToString() == k.ToString())
                        {
                            lblQuesNo.Text = "Q" + count.ToString() + " ";
                            lblQuestion.Text = dtTest.Rows[k - 1]["question"].ToString();
                            rbA.Text = dtTest.Rows[k - 1]["answerA"].ToString();
                            rbB.Text = dtTest.Rows[k - 1]["answerB"].ToString();
                            rbC.Text = dtTest.Rows[k - 1]["answerC"].ToString();
                            rbD.Text = dtTest.Rows[k - 1]["answerD"].ToString();
                            btnTest.Visible = false;
                            btnSubmit.Visible = true;
                            rbA.Checked = rbB.Checked = rbC.Checked = rbD.Checked = false;
                            randqs = randqs + ";" + k.ToString();
                        }
                    }
                    else
                    {
                        lblTutoringSystem.Visible = true;
                        double totalscore = ((double)score / (double)(count - 1)) * 100;
                        objProgress.updatescore(objConstants.fn_Syllabus, score, (count - 1), testtopicname, randqs);
                        lblTutoringSystem.Text = "The score of the test is " + totalscore.ToString() + "%";
                        lblAnswer.Visible = lblAnsopt.Visible = false;
                        rbA.Checked = rbB.Checked = rbC.Checked = rbD.Checked = false;
                        lblOptA.Visible = lblOptB.Visible = lblOptC.Visible = lblOptD.Visible = lblQuesNo.Visible =
                            lblQuestion.Visible = rbA.Visible = rbB.Visible = rbC.Visible = rbD.Visible = btnTest.Visible = btnChapterDisplay.Visible = false;
                        btnSubmit.Visible = true;
                        count = 1;
                        btnSubmit.Text = "Go to Home Page";
                        //CalculateProgress();
                    }
                }

            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                //lblException.Visible = true;
                //lblException.Text = ex.Message;
            }
            finally
            {
                objConstants = null;
                objProgress = null;
            }
        }

        private void lnklblHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FormController.ShowForm("Home");
        }

        private void btnBashShell_Click(object sender, EventArgs e)
        {
            OpenBash();
        }
        
    }
}
