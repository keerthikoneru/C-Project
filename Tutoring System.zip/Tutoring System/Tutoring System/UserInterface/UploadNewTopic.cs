﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tutoring_System.BLL;

namespace Tutoring_System.UserInterface
{
    public partial class UploadNewTopic : Form
    {
        public UploadNewTopic()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            UploadTopic objUpload = new UploadTopic();
            string message = "Only";
            if (txtTopic.Text != "" && txtVideoURL.Text != "" && txtQuizFilePath.Text != "" && txtChapter.Text != "")
            {
                if (txtPPTFilePath.Text != "")
                        message += "PPT ";
                if (txtUploadPdf.Text != "")
                    message += "PDF ";
                if (txtUploadText.Text != "")
                    message += "Text ";
                if (txtUploadWord.Text != "")
                    message += "Word ";
                DialogResult drresult = MessageBox.Show(message + "are selected to upload","Upload Material", MessageBoxButtons.OKCancel);
                //string topic = ;
                if (drresult == DialogResult.OK)
                {
                    string url = txtVideoURL.Text;
                    string videourl = url.Replace("watch?", "").Replace("v=", "v/");
                    string pptfileName = "";
                    string pdffileName = "";
                    string txtfileName = "";
                    string wordfileName = "";
                    if (txtPPTFilePath.Text != "")
                    {
                        string[] pathArr = txtPPTFilePath.Text.Split('\\');
                        string[] fileArr = pathArr.Last().Split('.');
                        pptfileName = pathArr.Last().ToString();
                    }

                    string[] quizArr = txtQuizFilePath.Text.Split('\\');
                    string[] quizfileArr = quizArr.Last().Split('.');
                    string quizfilename = quizArr.Last().ToString();
                    string chapter = txtChapter.Text;
                    //added for different files start 
                    if (txtUploadPdf.Text != "")
                    {
                        string[] pdfArr = txtUploadPdf.Text.Split('\\');
                        string[] pdffileArr = pdfArr.Last().Split('.');
                        pdffileName = pdfArr.Last().ToString();
                    }
                    if (txtUploadText.Text != "")
                    {
                        string[] txtArr = txtUploadText.Text.Split('\\');
                        string[] txtfileArr = txtArr.Last().Split('.');
                        txtfileName = txtArr.Last().ToString();
                    }
                    if (txtUploadWord.Text != "")
                    {
                        string[] wordArr = txtUploadWord.Text.Split('\\');
                        string[] wordfileArr = wordArr.Last().Split('.');
                        wordfileName = wordArr.Last().ToString();
                    }
                    //added for different files end
                    if (chapter.ToCharArray()[0] == txtTopic.Text.ToCharArray()[0] && char.IsDigit(chapter[0]) && char.IsDigit(txtTopic.Text[0]))
                    {
                        bool isUpload = objUpload.UploadTopics(pptfileName, pdffileName, txtfileName, wordfileName, quizfilename, txtPPTFilePath.Text, txtUploadPdf.Text, txtUploadText.Text, txtUploadWord.Text, txtQuizFilePath.Text, chapter, txtTopic.Text, videourl);
                        if (isUpload)
                        {
                            MessageBox.Show("New topic is added and Files are Uploaded!!!");
                            txtPPTFilePath.Clear();
                            txtTopic.Clear();
                            txtChapter.Clear();
                            txtVideoURL.Clear();
                            txtQuizFilePath.Clear();
                            txtUploadWord.Clear();
                            txtUploadText.Clear();
                            txtUploadPdf.Clear();
                            //RefreshGrid(0);
                        }
                        else
                        {
                            // MessageBox.Show("New topic cannot be added. Please contact Admin");
                        }
                    }
                }
                else
                {
                    
                }
            }
            else
            {
                
            }
        }

        private void btnBrowsePPT_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.AddExtension = true;
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "PPT files(*.pptx;*.ppt)|*.pptx;*.ppt";
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtPPTFilePath.Text = openFileDialog.FileName;
            }
        }

        private void btnQuizBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.AddExtension = true;
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "XML files (*.xml)|*.xml";
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtQuizFilePath.Text = openFileDialog.FileName;
            }
        }

        private void btnQuizBrowse_Validating(object sender, CancelEventArgs e)
        {
            string error = null;
            if (txtQuizFilePath.Text == "")
            {
                error = "Please select the Quiz file to upload";
                //e.Cancel = true;
            }
            errorProvider1.SetError((Control)sender, error);
        }

        private void txtVideoURL_Validating(object sender, CancelEventArgs e)
        {
            string error = null;
            if (txtVideoURL.Text == "")
            {
                error = "Please enter the VideoURL link";
                //e.Cancel = true;
            }
            errorProvider1.SetError((Control)sender, error);
        }

        private void txtTopic_Validating(object sender, CancelEventArgs e)
        {
            string error = null;
            if (txtTopic.Text == "" || !char.IsDigit(txtTopic.Text[0]))
            {
                error = "Please check the topic name";
                //e.Cancel = true;
            }
            errorProvider1.SetError((Control)sender, error);
        }

        private void txtChapter_Validating(object sender, CancelEventArgs e)
        {
            string error = null;
            if (txtChapter.Text == "" || !char.IsDigit(txtChapter.Text[0]))
            {
                error = "Please check the chapter name";
                //e.Cancel = true;
            }
            errorProvider1.SetError((Control)sender, error);
        }

        private void lnklblHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FormController.ShowForm("Home");
        }

        private void btnBrowsePdf_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.AddExtension = true;
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "PDF files (*.pdf)|*.pdf";
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtUploadPdf.Text = openFileDialog.FileName;
            }
        }

        private void btnBrowseText_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.AddExtension = true;
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "Text files (*.txt)|*.txt";
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtUploadText.Text = openFileDialog.FileName;
            }
        }

        private void btnBrowseWord_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.CheckFileExists = true;
            openFileDialog.AddExtension = true;
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "WORD files(*.docx;*.doc)|*.docx;*.doc";
            if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtUploadWord.Text = openFileDialog.FileName;
            }
        }
    }
}
