﻿namespace Tutoring_System.UserInterface
{
    partial class Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblQuestion = new System.Windows.Forms.Label();
            this.lblQuesNo = new System.Windows.Forms.Label();
            this.rbA = new System.Windows.Forms.RadioButton();
            this.rbB = new System.Windows.Forms.RadioButton();
            this.rbC = new System.Windows.Forms.RadioButton();
            this.rbD = new System.Windows.Forms.RadioButton();
            this.lblOptA = new System.Windows.Forms.Label();
            this.lblOptB = new System.Windows.Forms.Label();
            this.lblOptC = new System.Windows.Forms.Label();
            this.lblOptD = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.lblAnsopt = new System.Windows.Forms.Label();
            this.btnChapterDisplay = new System.Windows.Forms.Button();
            this.lblTutoringSystem = new System.Windows.Forms.Label();
            this.lnklblHome = new System.Windows.Forms.LinkLabel();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.btnBashShell = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblQuestion
            // 
            this.lblQuestion.AutoSize = true;
            this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestion.Location = new System.Drawing.Point(98, 50);
            this.lblQuestion.MaximumSize = new System.Drawing.Size(450, 150);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(86, 16);
            this.lblQuestion.TabIndex = 5;
            this.lblQuestion.Text = "lblQuestion";
            this.lblQuestion.Visible = false;
            // 
            // lblQuesNo
            // 
            this.lblQuesNo.AutoSize = true;
            this.lblQuesNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuesNo.Location = new System.Drawing.Point(24, 48);
            this.lblQuesNo.Name = "lblQuesNo";
            this.lblQuesNo.Size = new System.Drawing.Size(21, 18);
            this.lblQuesNo.TabIndex = 6;
            this.lblQuesNo.Text = "Q";
            this.lblQuesNo.Visible = false;
            // 
            // rbA
            // 
            this.rbA.AutoSize = true;
            this.rbA.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbA.Location = new System.Drawing.Point(101, 163);
            this.rbA.Name = "rbA";
            this.rbA.Size = new System.Drawing.Size(44, 17);
            this.rbA.TabIndex = 7;
            this.rbA.TabStop = true;
            this.rbA.Text = "rbA";
            this.rbA.UseVisualStyleBackColor = true;
            this.rbA.Visible = false;
            // 
            // rbB
            // 
            this.rbB.AutoSize = true;
            this.rbB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbB.Location = new System.Drawing.Point(101, 201);
            this.rbB.Name = "rbB";
            this.rbB.Size = new System.Drawing.Size(47, 19);
            this.rbB.TabIndex = 8;
            this.rbB.TabStop = true;
            this.rbB.Text = "rbB";
            this.rbB.UseVisualStyleBackColor = true;
            this.rbB.Visible = false;
            // 
            // rbC
            // 
            this.rbC.AutoSize = true;
            this.rbC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbC.Location = new System.Drawing.Point(101, 243);
            this.rbC.Name = "rbC";
            this.rbC.Size = new System.Drawing.Size(47, 19);
            this.rbC.TabIndex = 9;
            this.rbC.TabStop = true;
            this.rbC.Text = "rbC";
            this.rbC.UseVisualStyleBackColor = true;
            this.rbC.Visible = false;
            // 
            // rbD
            // 
            this.rbD.AutoSize = true;
            this.rbD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbD.Location = new System.Drawing.Point(101, 285);
            this.rbD.Name = "rbD";
            this.rbD.Size = new System.Drawing.Size(48, 19);
            this.rbD.TabIndex = 10;
            this.rbD.TabStop = true;
            this.rbD.Text = "rbD";
            this.rbD.UseVisualStyleBackColor = true;
            this.rbD.Visible = false;
            // 
            // lblOptA
            // 
            this.lblOptA.AutoSize = true;
            this.lblOptA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptA.Location = new System.Drawing.Point(46, 163);
            this.lblOptA.Name = "lblOptA";
            this.lblOptA.Size = new System.Drawing.Size(15, 15);
            this.lblOptA.TabIndex = 14;
            this.lblOptA.Text = "A";
            this.lblOptA.Visible = false;
            // 
            // lblOptB
            // 
            this.lblOptB.AutoSize = true;
            this.lblOptB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptB.Location = new System.Drawing.Point(46, 205);
            this.lblOptB.Name = "lblOptB";
            this.lblOptB.Size = new System.Drawing.Size(16, 15);
            this.lblOptB.TabIndex = 15;
            this.lblOptB.Text = "B";
            this.lblOptB.Visible = false;
            // 
            // lblOptC
            // 
            this.lblOptC.AutoSize = true;
            this.lblOptC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptC.Location = new System.Drawing.Point(46, 245);
            this.lblOptC.Name = "lblOptC";
            this.lblOptC.Size = new System.Drawing.Size(16, 15);
            this.lblOptC.TabIndex = 16;
            this.lblOptC.Text = "C";
            this.lblOptC.Visible = false;
            // 
            // lblOptD
            // 
            this.lblOptD.AutoSize = true;
            this.lblOptD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOptD.Location = new System.Drawing.Point(46, 287);
            this.lblOptD.Name = "lblOptD";
            this.lblOptD.Size = new System.Drawing.Size(17, 15);
            this.lblOptD.TabIndex = 17;
            this.lblOptD.Text = "D";
            this.lblOptD.Visible = false;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(540, 330);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(122, 45);
            this.btnSubmit.TabIndex = 18;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Visible = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnTest
            // 
            this.btnTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTest.Location = new System.Drawing.Point(540, 364);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(122, 46);
            this.btnTest.TabIndex = 19;
            this.btnTest.Text = "Start the Test";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnswer.Location = new System.Drawing.Point(46, 360);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(61, 15);
            this.lblAnswer.TabIndex = 20;
            this.lblAnswer.Text = "Answer :";
            this.lblAnswer.Visible = false;
            // 
            // lblAnsopt
            // 
            this.lblAnsopt.AutoSize = true;
            this.lblAnsopt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnsopt.ForeColor = System.Drawing.Color.Red;
            this.lblAnsopt.Location = new System.Drawing.Point(129, 360);
            this.lblAnsopt.Name = "lblAnsopt";
            this.lblAnsopt.Size = new System.Drawing.Size(75, 16);
            this.lblAnsopt.TabIndex = 21;
            this.lblAnsopt.Text = "lblAnswer";
            this.lblAnsopt.Visible = false;
            // 
            // btnChapterDisplay
            // 
            this.btnChapterDisplay.Enabled = false;
            this.btnChapterDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChapterDisplay.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnChapterDisplay.Location = new System.Drawing.Point(27, 2);
            this.btnChapterDisplay.Name = "btnChapterDisplay";
            this.btnChapterDisplay.Size = new System.Drawing.Size(200, 30);
            this.btnChapterDisplay.TabIndex = 22;
            this.btnChapterDisplay.Text = "Chapter";
            this.btnChapterDisplay.UseVisualStyleBackColor = true;
            this.btnChapterDisplay.Visible = false;
            // 
            // lblTutoringSystem
            // 
            this.lblTutoringSystem.AutoSize = true;
            this.lblTutoringSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTutoringSystem.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.lblTutoringSystem.Location = new System.Drawing.Point(147, 108);
            this.lblTutoringSystem.MaximumSize = new System.Drawing.Size(500, 200);
            this.lblTutoringSystem.Name = "lblTutoringSystem";
            this.lblTutoringSystem.Size = new System.Drawing.Size(0, 44);
            this.lblTutoringSystem.TabIndex = 23;
            // 
            // lnklblHome
            // 
            this.lnklblHome.AutoSize = true;
            this.lnklblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnklblHome.Location = new System.Drawing.Point(593, 16);
            this.lnklblHome.Name = "lnklblHome";
            this.lnklblHome.Size = new System.Drawing.Size(49, 16);
            this.lnklblHome.TabIndex = 36;
            this.lnklblHome.TabStop = true;
            this.lnklblHome.Text = "Home";
            this.lnklblHome.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnklblHome_LinkClicked);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Location = new System.Drawing.Point(1, 416);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.btnBashShell);
            this.splitContainer2.Panel2Collapsed = true;
            this.splitContainer2.Size = new System.Drawing.Size(671, 244);
            this.splitContainer2.SplitterDistance = 697;
            this.splitContainer2.TabIndex = 38;
            // 
            // btnBashShell
            // 
            this.btnBashShell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBashShell.Location = new System.Drawing.Point(261, 192);
            this.btnBashShell.Name = "btnBashShell";
            this.btnBashShell.Size = new System.Drawing.Size(151, 42);
            this.btnBashShell.TabIndex = 1;
            this.btnBashShell.Text = "Reopen the BashShell";
            this.btnBashShell.UseVisualStyleBackColor = true;
            this.btnBashShell.Click += new System.EventHandler(this.btnBashShell_Click);
            // 
            // Test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 662);
            this.ControlBox = false;
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.lnklblHome);
            this.Controls.Add(this.lblTutoringSystem);
            this.Controls.Add(this.btnChapterDisplay);
            this.Controls.Add(this.lblAnsopt);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.lblOptD);
            this.Controls.Add(this.lblOptC);
            this.Controls.Add(this.lblOptB);
            this.Controls.Add(this.lblOptA);
            this.Controls.Add(this.rbD);
            this.Controls.Add(this.rbC);
            this.Controls.Add(this.rbB);
            this.Controls.Add(this.rbA);
            this.Controls.Add(this.lblQuesNo);
            this.Controls.Add(this.lblQuestion);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(700, 700);
            this.MinimumSize = new System.Drawing.Size(700, 700);
            this.Name = "Test";
            this.Text = "Test";
            this.Load += new System.EventHandler(this.Test_Load);
            this.splitContainer2.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuestion;
        private System.Windows.Forms.Label lblQuesNo;
        private System.Windows.Forms.RadioButton rbA;
        private System.Windows.Forms.RadioButton rbB;
        private System.Windows.Forms.RadioButton rbC;
        private System.Windows.Forms.RadioButton rbD;
        private System.Windows.Forms.Label lblOptA;
        private System.Windows.Forms.Label lblOptB;
        private System.Windows.Forms.Label lblOptC;
        private System.Windows.Forms.Label lblOptD;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Label lblAnsopt;
        private System.Windows.Forms.Button btnChapterDisplay;
        private System.Windows.Forms.Label lblTutoringSystem;
        private System.Windows.Forms.LinkLabel lnklblHome;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Button btnBashShell;
    }
}