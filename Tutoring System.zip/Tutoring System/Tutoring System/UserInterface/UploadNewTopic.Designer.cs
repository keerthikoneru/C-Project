﻿namespace Tutoring_System.UserInterface
{
    partial class UploadNewTopic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblUploadNew = new System.Windows.Forms.Label();
            this.lblUploadChapter = new System.Windows.Forms.Label();
            this.txtChapter = new System.Windows.Forms.TextBox();
            this.lblSyllabus = new System.Windows.Forms.Label();
            this.txtTopic = new System.Windows.Forms.TextBox();
            this.lblVideoURL = new System.Windows.Forms.Label();
            this.txtVideoURL = new System.Windows.Forms.TextBox();
            this.lblPPTFileUpload = new System.Windows.Forms.Label();
            this.txtPPTFilePath = new System.Windows.Forms.RichTextBox();
            this.btnBrowsePPT = new System.Windows.Forms.Button();
            this.lblQuizFileUpload = new System.Windows.Forms.Label();
            this.txtQuizFilePath = new System.Windows.Forms.RichTextBox();
            this.btnQuizBrowse = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.lnklblHome = new System.Windows.Forms.LinkLabel();
            this.lblUploadpdf = new System.Windows.Forms.Label();
            this.txtUploadPdf = new System.Windows.Forms.RichTextBox();
            this.btnBrowsePdf = new System.Windows.Forms.Button();
            this.lblUploadTxt = new System.Windows.Forms.Label();
            this.txtUploadText = new System.Windows.Forms.RichTextBox();
            this.btnBrowseText = new System.Windows.Forms.Button();
            this.lblUploadWord = new System.Windows.Forms.Label();
            this.txtUploadWord = new System.Windows.Forms.RichTextBox();
            this.btnBrowseWord = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblUploadNew
            // 
            this.lblUploadNew.AutoSize = true;
            this.lblUploadNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUploadNew.Location = new System.Drawing.Point(287, 21);
            this.lblUploadNew.Name = "lblUploadNew";
            this.lblUploadNew.Size = new System.Drawing.Size(183, 24);
            this.lblUploadNew.TabIndex = 2;
            this.lblUploadNew.Text = "Upload New Topic";
            // 
            // lblUploadChapter
            // 
            this.lblUploadChapter.AutoSize = true;
            this.lblUploadChapter.Location = new System.Drawing.Point(50, 77);
            this.lblUploadChapter.Name = "lblUploadChapter";
            this.lblUploadChapter.Size = new System.Drawing.Size(75, 13);
            this.lblUploadChapter.TabIndex = 22;
            this.lblUploadChapter.Text = "Chapter Name";
            // 
            // txtChapter
            // 
            this.txtChapter.Location = new System.Drawing.Point(140, 74);
            this.txtChapter.Name = "txtChapter";
            this.txtChapter.Size = new System.Drawing.Size(226, 20);
            this.txtChapter.TabIndex = 23;
            this.txtChapter.Validating += new System.ComponentModel.CancelEventHandler(this.txtChapter_Validating);
            // 
            // lblSyllabus
            // 
            this.lblSyllabus.AutoSize = true;
            this.lblSyllabus.Location = new System.Drawing.Point(403, 77);
            this.lblSyllabus.Name = "lblSyllabus";
            this.lblSyllabus.Size = new System.Drawing.Size(65, 13);
            this.lblSyllabus.TabIndex = 21;
            this.lblSyllabus.Text = "Topic Name";
            // 
            // txtTopic
            // 
            this.txtTopic.Location = new System.Drawing.Point(491, 74);
            this.txtTopic.Name = "txtTopic";
            this.txtTopic.Size = new System.Drawing.Size(226, 20);
            this.txtTopic.TabIndex = 24;
            this.txtTopic.Validating += new System.ComponentModel.CancelEventHandler(this.txtTopic_Validating);
            // 
            // lblVideoURL
            // 
            this.lblVideoURL.AutoSize = true;
            this.lblVideoURL.Location = new System.Drawing.Point(50, 120);
            this.lblVideoURL.Name = "lblVideoURL";
            this.lblVideoURL.Size = new System.Drawing.Size(59, 13);
            this.lblVideoURL.TabIndex = 20;
            this.lblVideoURL.Text = "Video URL";
            // 
            // txtVideoURL
            // 
            this.txtVideoURL.Location = new System.Drawing.Point(140, 113);
            this.txtVideoURL.Name = "txtVideoURL";
            this.txtVideoURL.Size = new System.Drawing.Size(226, 20);
            this.txtVideoURL.TabIndex = 25;
            this.txtVideoURL.Validating += new System.ComponentModel.CancelEventHandler(this.txtVideoURL_Validating);
            // 
            // lblPPTFileUpload
            // 
            this.lblPPTFileUpload.AutoSize = true;
            this.lblPPTFileUpload.Location = new System.Drawing.Point(50, 164);
            this.lblPPTFileUpload.Name = "lblPPTFileUpload";
            this.lblPPTFileUpload.Size = new System.Drawing.Size(84, 13);
            this.lblPPTFileUpload.TabIndex = 19;
            this.lblPPTFileUpload.Text = "Upload PPT File";
            // 
            // txtPPTFilePath
            // 
            this.txtPPTFilePath.Enabled = false;
            this.txtPPTFilePath.Location = new System.Drawing.Point(140, 161);
            this.txtPPTFilePath.Name = "txtPPTFilePath";
            this.txtPPTFilePath.Size = new System.Drawing.Size(143, 20);
            this.txtPPTFilePath.TabIndex = 18;
            this.txtPPTFilePath.Text = "";
            // 
            // btnBrowsePPT
            // 
            this.btnBrowsePPT.Location = new System.Drawing.Point(291, 158);
            this.btnBrowsePPT.Name = "btnBrowsePPT";
            this.btnBrowsePPT.Size = new System.Drawing.Size(75, 23);
            this.btnBrowsePPT.TabIndex = 27;
            this.btnBrowsePPT.Text = "Browse";
            this.btnBrowsePPT.UseVisualStyleBackColor = true;
            this.btnBrowsePPT.Click += new System.EventHandler(this.btnBrowsePPT_Click);
            // 
            // lblQuizFileUpload
            // 
            this.lblQuizFileUpload.AutoSize = true;
            this.lblQuizFileUpload.Location = new System.Drawing.Point(403, 120);
            this.lblQuizFileUpload.Name = "lblQuizFileUpload";
            this.lblQuizFileUpload.Size = new System.Drawing.Size(82, 13);
            this.lblQuizFileUpload.TabIndex = 17;
            this.lblQuizFileUpload.Text = "Upload quiz File";
            // 
            // txtQuizFilePath
            // 
            this.txtQuizFilePath.Enabled = false;
            this.txtQuizFilePath.Location = new System.Drawing.Point(491, 113);
            this.txtQuizFilePath.Name = "txtQuizFilePath";
            this.txtQuizFilePath.Size = new System.Drawing.Size(143, 20);
            this.txtQuizFilePath.TabIndex = 16;
            this.txtQuizFilePath.Text = "";
            // 
            // btnQuizBrowse
            // 
            this.btnQuizBrowse.Location = new System.Drawing.Point(642, 110);
            this.btnQuizBrowse.Name = "btnQuizBrowse";
            this.btnQuizBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnQuizBrowse.TabIndex = 26;
            this.btnQuizBrowse.Text = "Browse";
            this.btnQuizBrowse.UseVisualStyleBackColor = true;
            this.btnQuizBrowse.Click += new System.EventHandler(this.btnQuizBrowse_Click);
            this.btnQuizBrowse.Validating += new System.ComponentModel.CancelEventHandler(this.btnQuizBrowse_Validating);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(329, 299);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(106, 43);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // lnklblHome
            // 
            this.lnklblHome.AutoSize = true;
            this.lnklblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnklblHome.Location = new System.Drawing.Point(668, 21);
            this.lnklblHome.Name = "lnklblHome";
            this.lnklblHome.Size = new System.Drawing.Size(49, 16);
            this.lnklblHome.TabIndex = 35;
            this.lnklblHome.TabStop = true;
            this.lnklblHome.Text = "Home";
            this.lnklblHome.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnklblHome_LinkClicked);
            // 
            // lblUploadpdf
            // 
            this.lblUploadpdf.AutoSize = true;
            this.lblUploadpdf.Location = new System.Drawing.Point(403, 164);
            this.lblUploadpdf.Name = "lblUploadpdf";
            this.lblUploadpdf.Size = new System.Drawing.Size(84, 13);
            this.lblUploadpdf.TabIndex = 38;
            this.lblUploadpdf.Text = "Upload PDF File";
            // 
            // txtUploadPdf
            // 
            this.txtUploadPdf.Enabled = false;
            this.txtUploadPdf.Location = new System.Drawing.Point(491, 160);
            this.txtUploadPdf.Name = "txtUploadPdf";
            this.txtUploadPdf.Size = new System.Drawing.Size(143, 20);
            this.txtUploadPdf.TabIndex = 41;
            this.txtUploadPdf.Text = "";
            // 
            // btnBrowsePdf
            // 
            this.btnBrowsePdf.Location = new System.Drawing.Point(642, 157);
            this.btnBrowsePdf.Name = "btnBrowsePdf";
            this.btnBrowsePdf.Size = new System.Drawing.Size(75, 23);
            this.btnBrowsePdf.TabIndex = 28;
            this.btnBrowsePdf.Text = "Browse";
            this.btnBrowsePdf.UseVisualStyleBackColor = true;
            this.btnBrowsePdf.Click += new System.EventHandler(this.btnBrowsePdf_Click);
            // 
            // lblUploadTxt
            // 
            this.lblUploadTxt.AutoSize = true;
            this.lblUploadTxt.Location = new System.Drawing.Point(50, 211);
            this.lblUploadTxt.Name = "lblUploadTxt";
            this.lblUploadTxt.Size = new System.Drawing.Size(84, 13);
            this.lblUploadTxt.TabIndex = 33;
            this.lblUploadTxt.Text = "Upload Text File";
            // 
            // txtUploadText
            // 
            this.txtUploadText.Enabled = false;
            this.txtUploadText.Location = new System.Drawing.Point(140, 208);
            this.txtUploadText.Name = "txtUploadText";
            this.txtUploadText.Size = new System.Drawing.Size(143, 20);
            this.txtUploadText.TabIndex = 34;
            this.txtUploadText.Text = "";
            // 
            // btnBrowseText
            // 
            this.btnBrowseText.Location = new System.Drawing.Point(291, 206);
            this.btnBrowseText.Name = "btnBrowseText";
            this.btnBrowseText.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseText.TabIndex = 29;
            this.btnBrowseText.Text = "Browse";
            this.btnBrowseText.UseVisualStyleBackColor = true;
            this.btnBrowseText.Click += new System.EventHandler(this.btnBrowseText_Click);
            // 
            // lblUploadWord
            // 
            this.lblUploadWord.AutoSize = true;
            this.lblUploadWord.Location = new System.Drawing.Point(403, 211);
            this.lblUploadWord.Name = "lblUploadWord";
            this.lblUploadWord.Size = new System.Drawing.Size(89, 13);
            this.lblUploadWord.TabIndex = 36;
            this.lblUploadWord.Text = "Upload Word File";
            // 
            // txtUploadWord
            // 
            this.txtUploadWord.Enabled = false;
            this.txtUploadWord.Location = new System.Drawing.Point(491, 208);
            this.txtUploadWord.Name = "txtUploadWord";
            this.txtUploadWord.Size = new System.Drawing.Size(143, 20);
            this.txtUploadWord.TabIndex = 37;
            this.txtUploadWord.Text = "";
            // 
            // btnBrowseWord
            // 
            this.btnBrowseWord.Location = new System.Drawing.Point(642, 206);
            this.btnBrowseWord.Name = "btnBrowseWord";
            this.btnBrowseWord.Size = new System.Drawing.Size(75, 23);
            this.btnBrowseWord.TabIndex = 30;
            this.btnBrowseWord.Text = "Browse";
            this.btnBrowseWord.UseVisualStyleBackColor = true;
            this.btnBrowseWord.Click += new System.EventHandler(this.btnBrowseWord_Click);
            // 
            // UploadNewTopic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 512);
            this.ControlBox = false;
            this.Controls.Add(this.btnBrowseWord);
            this.Controls.Add(this.txtUploadWord);
            this.Controls.Add(this.lblUploadWord);
            this.Controls.Add(this.btnBrowseText);
            this.Controls.Add(this.txtUploadText);
            this.Controls.Add(this.lblUploadTxt);
            this.Controls.Add(this.btnBrowsePdf);
            this.Controls.Add(this.txtUploadPdf);
            this.Controls.Add(this.lblUploadpdf);
            this.Controls.Add(this.lnklblHome);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnQuizBrowse);
            this.Controls.Add(this.txtQuizFilePath);
            this.Controls.Add(this.lblQuizFileUpload);
            this.Controls.Add(this.btnBrowsePPT);
            this.Controls.Add(this.txtPPTFilePath);
            this.Controls.Add(this.lblPPTFileUpload);
            this.Controls.Add(this.txtVideoURL);
            this.Controls.Add(this.lblVideoURL);
            this.Controls.Add(this.txtTopic);
            this.Controls.Add(this.lblSyllabus);
            this.Controls.Add(this.txtChapter);
            this.Controls.Add(this.lblUploadChapter);
            this.Controls.Add(this.lblUploadNew);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(850, 550);
            this.MinimumSize = new System.Drawing.Size(850, 550);
            this.Name = "UploadNewTopic";
            this.Text = "UploadNewTopic";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUploadNew;
        private System.Windows.Forms.Label lblUploadChapter;
        private System.Windows.Forms.TextBox txtChapter;
        private System.Windows.Forms.Label lblSyllabus;
        private System.Windows.Forms.TextBox txtTopic;
        private System.Windows.Forms.Label lblVideoURL;
        private System.Windows.Forms.TextBox txtVideoURL;
        private System.Windows.Forms.Label lblPPTFileUpload;
        private System.Windows.Forms.RichTextBox txtPPTFilePath;
        private System.Windows.Forms.Button btnBrowsePPT;
        private System.Windows.Forms.Label lblQuizFileUpload;
        private System.Windows.Forms.RichTextBox txtQuizFilePath;
        private System.Windows.Forms.Button btnQuizBrowse;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.LinkLabel lnklblHome;
        private System.Windows.Forms.Label lblUploadpdf;
        private System.Windows.Forms.RichTextBox txtUploadPdf;
        private System.Windows.Forms.Button btnBrowseWord;
        private System.Windows.Forms.RichTextBox txtUploadWord;
        private System.Windows.Forms.Label lblUploadWord;
        private System.Windows.Forms.Button btnBrowseText;
        private System.Windows.Forms.RichTextBox txtUploadText;
        private System.Windows.Forms.Label lblUploadTxt;
        private System.Windows.Forms.Button btnBrowsePdf;
    }
}