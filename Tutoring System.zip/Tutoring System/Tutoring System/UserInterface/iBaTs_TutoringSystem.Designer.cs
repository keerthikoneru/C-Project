﻿namespace Tutoring_System.UserInterface
{
    partial class iBaTs_TutoringSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(iBaTs_TutoringSystem));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splt_syllabus = new System.Windows.Forms.SplitContainer();
            this.splt_bash = new System.Windows.Forms.SplitContainer();
            this.lblTypeofMaterial = new System.Windows.Forms.Label();
            this.rbword = new System.Windows.Forms.RadioButton();
            this.rbtxt = new System.Windows.Forms.RadioButton();
            this.rbPDF = new System.Windows.Forms.RadioButton();
            this.rbppt = new System.Windows.Forms.RadioButton();
            this.rtbMaterial = new System.Windows.Forms.RichTextBox();
            this.axAcroPDF1 = new AxAcroPDFLib.AxAcroPDF();
            this.axShockwaveFlash1 = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.lblTutoringSystem = new System.Windows.Forms.Label();
            this.lblException = new System.Windows.Forms.Label();
            this.btnBashShell = new System.Windows.Forms.Button();
            this.btnQuizBrowse = new System.Windows.Forms.Button();
            this.btnChapterDisplay = new System.Windows.Forms.Button();
            this.txtChapter = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblUploadChapter = new System.Windows.Forms.Label();
            this.lblSyllabus = new System.Windows.Forms.Label();
            this.txtQuizFilePath = new System.Windows.Forms.RichTextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblQuizFileUpload = new System.Windows.Forms.Label();
            this.txtTopic = new System.Windows.Forms.TextBox();
            this.lblVideoURL = new System.Windows.Forms.Label();
            this.txtVideoURL = new System.Windows.Forms.TextBox();
            this.lblPPTFileUpload = new System.Windows.Forms.Label();
            this.txtPPTFilePath = new System.Windows.Forms.RichTextBox();
            this.lnklblHome = new System.Windows.Forms.LinkLabel();
            this.lblChapter = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.cmbChapters = new System.Windows.Forms.ComboBox();
            this.btnToc = new System.Windows.Forms.Button();
            this.pnlProgressBar = new System.Windows.Forms.Panel();
            this.rtbProgress = new System.Windows.Forms.RichTextBox();
            this.pbar = new System.Windows.Forms.ProgressBar();
            this.dGV_topics = new System.Windows.Forms.DataGridView();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.splt_syllabus)).BeginInit();
            this.splt_syllabus.Panel1.SuspendLayout();
            this.splt_syllabus.Panel2.SuspendLayout();
            this.splt_syllabus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splt_bash)).BeginInit();
            this.splt_bash.Panel1.SuspendLayout();
            this.splt_bash.Panel2.SuspendLayout();
            this.splt_bash.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axAcroPDF1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axShockwaveFlash1)).BeginInit();
            this.pnlProgressBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_topics)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // splt_syllabus
            // 
            this.splt_syllabus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splt_syllabus.Location = new System.Drawing.Point(0, 0);
            this.splt_syllabus.Name = "splt_syllabus";
            // 
            // splt_syllabus.Panel1
            // 
            this.splt_syllabus.Panel1.AccessibleName = "splt_syllabus.pnltutor";
            this.splt_syllabus.Panel1.AutoScroll = true;
            this.splt_syllabus.Panel1.Controls.Add(this.splt_bash);
            // 
            // splt_syllabus.Panel2
            // 
            this.splt_syllabus.Panel2.AccessibleName = "pnl_syllabus";
            this.splt_syllabus.Panel2.AutoScroll = true;
            this.splt_syllabus.Panel2.Controls.Add(this.lnklblHome);
            this.splt_syllabus.Panel2.Controls.Add(this.lblChapter);
            this.splt_syllabus.Panel2.Controls.Add(this.btnUpload);
            this.splt_syllabus.Panel2.Controls.Add(this.cmbChapters);
            this.splt_syllabus.Panel2.Controls.Add(this.btnToc);
            this.splt_syllabus.Panel2.Controls.Add(this.pnlProgressBar);
            this.splt_syllabus.Panel2.Controls.Add(this.dGV_topics);
            this.splt_syllabus.Size = new System.Drawing.Size(1057, 692);
            this.splt_syllabus.SplitterDistance = 684;
            this.splt_syllabus.TabIndex = 0;
            // 
            // splt_bash
            // 
            this.splt_bash.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splt_bash.Location = new System.Drawing.Point(0, 0);
            this.splt_bash.Name = "splt_bash";
            this.splt_bash.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splt_bash.Panel1
            // 
            this.splt_bash.Panel1.AccessibleName = "pnl_tutor";
            this.splt_bash.Panel1.Controls.Add(this.lblTypeofMaterial);
            this.splt_bash.Panel1.Controls.Add(this.rbword);
            this.splt_bash.Panel1.Controls.Add(this.rbtxt);
            this.splt_bash.Panel1.Controls.Add(this.rbPDF);
            this.splt_bash.Panel1.Controls.Add(this.rbppt);
            this.splt_bash.Panel1.Controls.Add(this.rtbMaterial);
            this.splt_bash.Panel1.Controls.Add(this.axAcroPDF1);
            this.splt_bash.Panel1.Controls.Add(this.axShockwaveFlash1);
            this.splt_bash.Panel1.Controls.Add(this.lblTutoringSystem);
            this.splt_bash.Panel1.Controls.Add(this.lblException);
            // 
            // splt_bash.Panel2
            // 
            this.splt_bash.Panel2.AccessibleName = "pnl_bash";
            this.splt_bash.Panel2.Controls.Add(this.btnBashShell);
            this.splt_bash.Panel2.Controls.Add(this.btnQuizBrowse);
            this.splt_bash.Panel2.Controls.Add(this.btnChapterDisplay);
            this.splt_bash.Panel2.Controls.Add(this.txtChapter);
            this.splt_bash.Panel2.Controls.Add(this.btnSave);
            this.splt_bash.Panel2.Controls.Add(this.lblUploadChapter);
            this.splt_bash.Panel2.Controls.Add(this.lblSyllabus);
            this.splt_bash.Panel2.Controls.Add(this.txtQuizFilePath);
            this.splt_bash.Panel2.Controls.Add(this.btnBrowse);
            this.splt_bash.Panel2.Controls.Add(this.lblQuizFileUpload);
            this.splt_bash.Panel2.Controls.Add(this.txtTopic);
            this.splt_bash.Panel2.Controls.Add(this.lblVideoURL);
            this.splt_bash.Panel2.Controls.Add(this.txtVideoURL);
            this.splt_bash.Panel2.Controls.Add(this.lblPPTFileUpload);
            this.splt_bash.Panel2.Controls.Add(this.txtPPTFilePath);
            this.splt_bash.Size = new System.Drawing.Size(684, 692);
            this.splt_bash.SplitterDistance = 395;
            this.splt_bash.TabIndex = 0;
            // 
            // lblTypeofMaterial
            // 
            this.lblTypeofMaterial.AutoSize = true;
            this.lblTypeofMaterial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeofMaterial.Location = new System.Drawing.Point(33, 138);
            this.lblTypeofMaterial.Name = "lblTypeofMaterial";
            this.lblTypeofMaterial.Size = new System.Drawing.Size(173, 16);
            this.lblTypeofMaterial.TabIndex = 34;
            this.lblTypeofMaterial.Text = "Select one of the below:";
            this.lblTypeofMaterial.Visible = false;
            // 
            // rbword
            // 
            this.rbword.AutoSize = true;
            this.rbword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbword.Location = new System.Drawing.Point(434, 206);
            this.rbword.Name = "rbword";
            this.rbword.Size = new System.Drawing.Size(55, 17);
            this.rbword.TabIndex = 33;
            this.rbword.TabStop = true;
            this.rbword.Text = "Word";
            this.rbword.UseVisualStyleBackColor = true;
            this.rbword.Visible = false;
            this.rbword.CheckedChanged += new System.EventHandler(this.rbword_CheckedChanged);
            // 
            // rbtxt
            // 
            this.rbtxt.AutoSize = true;
            this.rbtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtxt.Location = new System.Drawing.Point(434, 170);
            this.rbtxt.Name = "rbtxt";
            this.rbtxt.Size = new System.Drawing.Size(50, 17);
            this.rbtxt.TabIndex = 32;
            this.rbtxt.TabStop = true;
            this.rbtxt.Text = "Text";
            this.rbtxt.UseVisualStyleBackColor = true;
            this.rbtxt.Visible = false;
            this.rbtxt.CheckedChanged += new System.EventHandler(this.rbtxt_CheckedChanged);
            // 
            // rbPDF
            // 
            this.rbPDF.AutoSize = true;
            this.rbPDF.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbPDF.Location = new System.Drawing.Point(36, 206);
            this.rbPDF.Name = "rbPDF";
            this.rbPDF.Size = new System.Drawing.Size(49, 17);
            this.rbPDF.TabIndex = 31;
            this.rbPDF.TabStop = true;
            this.rbPDF.Text = "PDF";
            this.rbPDF.UseVisualStyleBackColor = true;
            this.rbPDF.Visible = false;
            this.rbPDF.CheckedChanged += new System.EventHandler(this.rbPDF_CheckedChanged);
            // 
            // rbppt
            // 
            this.rbppt.AutoSize = true;
            this.rbppt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbppt.Location = new System.Drawing.Point(36, 170);
            this.rbppt.Name = "rbppt";
            this.rbppt.Size = new System.Drawing.Size(96, 17);
            this.rbppt.TabIndex = 30;
            this.rbppt.TabStop = true;
            this.rbppt.Text = "Presentation";
            this.rbppt.UseVisualStyleBackColor = true;
            this.rbppt.Visible = false;
            this.rbppt.CheckedChanged += new System.EventHandler(this.rbppt_CheckedChanged);
            // 
            // rtbMaterial
            // 
            this.rtbMaterial.Location = new System.Drawing.Point(12, 229);
            this.rtbMaterial.Name = "rtbMaterial";
            this.rtbMaterial.Size = new System.Drawing.Size(252, 157);
            this.rtbMaterial.TabIndex = 29;
            this.rtbMaterial.Text = "";
            this.rtbMaterial.Visible = false;
            // 
            // axAcroPDF1
            // 
            this.axAcroPDF1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.axAcroPDF1.Enabled = true;
            this.axAcroPDF1.Location = new System.Drawing.Point(468, 229);
            this.axAcroPDF1.Name = "axAcroPDF1";
            this.axAcroPDF1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAcroPDF1.OcxState")));
            this.axAcroPDF1.Size = new System.Drawing.Size(192, 192);
            this.axAcroPDF1.TabIndex = 28;
            this.axAcroPDF1.Visible = false;
            // 
            // axShockwaveFlash1
            // 
            this.axShockwaveFlash1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.axShockwaveFlash1.Enabled = true;
            this.axShockwaveFlash1.Location = new System.Drawing.Point(270, 229);
            this.axShockwaveFlash1.Name = "axShockwaveFlash1";
            this.axShockwaveFlash1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axShockwaveFlash1.OcxState")));
            this.axShockwaveFlash1.Size = new System.Drawing.Size(192, 192);
            this.axShockwaveFlash1.TabIndex = 2;
            this.axShockwaveFlash1.Visible = false;
            // 
            // lblTutoringSystem
            // 
            this.lblTutoringSystem.AutoSize = true;
            this.lblTutoringSystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTutoringSystem.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.lblTutoringSystem.Location = new System.Drawing.Point(133, 46);
            this.lblTutoringSystem.MaximumSize = new System.Drawing.Size(500, 200);
            this.lblTutoringSystem.Name = "lblTutoringSystem";
            this.lblTutoringSystem.Size = new System.Drawing.Size(327, 44);
            this.lblTutoringSystem.TabIndex = 1;
            this.lblTutoringSystem.Text = "lblTutoringSystem";
            // 
            // lblException
            // 
            this.lblException.AutoSize = true;
            this.lblException.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblException.Location = new System.Drawing.Point(33, 54);
            this.lblException.Name = "lblException";
            this.lblException.Size = new System.Drawing.Size(86, 15);
            this.lblException.TabIndex = 1;
            this.lblException.Text = "lblException";
            this.lblException.Visible = false;
            // 
            // btnBashShell
            // 
            this.btnBashShell.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBashShell.Location = new System.Drawing.Point(499, 226);
            this.btnBashShell.Name = "btnBashShell";
            this.btnBashShell.Size = new System.Drawing.Size(151, 42);
            this.btnBashShell.TabIndex = 0;
            this.btnBashShell.Text = "Reopen the BashShell";
            this.btnBashShell.UseVisualStyleBackColor = true;
            this.btnBashShell.Click += new System.EventHandler(this.btnBashShell_Click);
            // 
            // btnQuizBrowse
            // 
            this.btnQuizBrowse.Location = new System.Drawing.Point(405, 224);
            this.btnQuizBrowse.Name = "btnQuizBrowse";
            this.btnQuizBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnQuizBrowse.TabIndex = 26;
            this.btnQuizBrowse.Text = "Browse";
            this.btnQuizBrowse.UseVisualStyleBackColor = true;
            this.btnQuizBrowse.Visible = false;
            // 
            // btnChapterDisplay
            // 
            this.btnChapterDisplay.Enabled = false;
            this.btnChapterDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChapterDisplay.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnChapterDisplay.Location = new System.Drawing.Point(12, 21);
            this.btnChapterDisplay.Name = "btnChapterDisplay";
            this.btnChapterDisplay.Size = new System.Drawing.Size(200, 30);
            this.btnChapterDisplay.TabIndex = 17;
            this.btnChapterDisplay.Text = "Chapter";
            this.btnChapterDisplay.UseVisualStyleBackColor = true;
            this.btnChapterDisplay.Visible = false;
            // 
            // txtChapter
            // 
            this.txtChapter.Location = new System.Drawing.Point(234, 66);
            this.txtChapter.Name = "txtChapter";
            this.txtChapter.Size = new System.Drawing.Size(226, 20);
            this.txtChapter.TabIndex = 22;
            this.txtChapter.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(385, 21);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 27;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Visible = false;
            // 
            // lblUploadChapter
            // 
            this.lblUploadChapter.AutoSize = true;
            this.lblUploadChapter.Location = new System.Drawing.Point(137, 69);
            this.lblUploadChapter.Name = "lblUploadChapter";
            this.lblUploadChapter.Size = new System.Drawing.Size(75, 13);
            this.lblUploadChapter.TabIndex = 21;
            this.lblUploadChapter.Text = "Chapter Name";
            this.lblUploadChapter.Visible = false;
            // 
            // lblSyllabus
            // 
            this.lblSyllabus.AutoSize = true;
            this.lblSyllabus.Location = new System.Drawing.Point(138, 105);
            this.lblSyllabus.Name = "lblSyllabus";
            this.lblSyllabus.Size = new System.Drawing.Size(65, 13);
            this.lblSyllabus.TabIndex = 3;
            this.lblSyllabus.Text = "Topic Name";
            this.lblSyllabus.Visible = false;
            // 
            // txtQuizFilePath
            // 
            this.txtQuizFilePath.Enabled = false;
            this.txtQuizFilePath.Location = new System.Drawing.Point(234, 224);
            this.txtQuizFilePath.Name = "txtQuizFilePath";
            this.txtQuizFilePath.Size = new System.Drawing.Size(143, 20);
            this.txtQuizFilePath.TabIndex = 12;
            this.txtQuizFilePath.Text = "";
            this.txtQuizFilePath.Visible = false;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(405, 178);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 25;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Visible = false;
            // 
            // lblQuizFileUpload
            // 
            this.lblQuizFileUpload.AutoSize = true;
            this.lblQuizFileUpload.Location = new System.Drawing.Point(137, 224);
            this.lblQuizFileUpload.Name = "lblQuizFileUpload";
            this.lblQuizFileUpload.Size = new System.Drawing.Size(82, 13);
            this.lblQuizFileUpload.TabIndex = 11;
            this.lblQuizFileUpload.Text = "Upload quiz File";
            this.lblQuizFileUpload.Visible = false;
            // 
            // txtTopic
            // 
            this.txtTopic.Location = new System.Drawing.Point(234, 102);
            this.txtTopic.Name = "txtTopic";
            this.txtTopic.Size = new System.Drawing.Size(226, 20);
            this.txtTopic.TabIndex = 23;
            this.txtTopic.Visible = false;
            // 
            // lblVideoURL
            // 
            this.lblVideoURL.AutoSize = true;
            this.lblVideoURL.Location = new System.Drawing.Point(138, 139);
            this.lblVideoURL.Name = "lblVideoURL";
            this.lblVideoURL.Size = new System.Drawing.Size(59, 13);
            this.lblVideoURL.TabIndex = 9;
            this.lblVideoURL.Text = "Video URL";
            this.lblVideoURL.Visible = false;
            // 
            // txtVideoURL
            // 
            this.txtVideoURL.Location = new System.Drawing.Point(234, 139);
            this.txtVideoURL.Name = "txtVideoURL";
            this.txtVideoURL.Size = new System.Drawing.Size(226, 20);
            this.txtVideoURL.TabIndex = 24;
            this.txtVideoURL.Visible = false;
            // 
            // lblPPTFileUpload
            // 
            this.lblPPTFileUpload.AutoSize = true;
            this.lblPPTFileUpload.Location = new System.Drawing.Point(138, 181);
            this.lblPPTFileUpload.Name = "lblPPTFileUpload";
            this.lblPPTFileUpload.Size = new System.Drawing.Size(84, 13);
            this.lblPPTFileUpload.TabIndex = 4;
            this.lblPPTFileUpload.Text = "Upload PPT File";
            this.lblPPTFileUpload.Visible = false;
            // 
            // txtPPTFilePath
            // 
            this.txtPPTFilePath.Enabled = false;
            this.txtPPTFilePath.Location = new System.Drawing.Point(234, 181);
            this.txtPPTFilePath.Name = "txtPPTFilePath";
            this.txtPPTFilePath.Size = new System.Drawing.Size(143, 20);
            this.txtPPTFilePath.TabIndex = 5;
            this.txtPPTFilePath.Text = "";
            this.txtPPTFilePath.Visible = false;
            // 
            // lnklblHome
            // 
            this.lnklblHome.AutoSize = true;
            this.lnklblHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnklblHome.Location = new System.Drawing.Point(171, 11);
            this.lnklblHome.Name = "lnklblHome";
            this.lnklblHome.Size = new System.Drawing.Size(49, 16);
            this.lnklblHome.TabIndex = 30;
            this.lnklblHome.TabStop = true;
            this.lnklblHome.Text = "Home";
            this.lnklblHome.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnklblHome_LinkClicked);
            // 
            // lblChapter
            // 
            this.lblChapter.AutoSize = true;
            this.lblChapter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChapter.Location = new System.Drawing.Point(5, 49);
            this.lblChapter.Name = "lblChapter";
            this.lblChapter.Size = new System.Drawing.Size(57, 15);
            this.lblChapter.TabIndex = 20;
            this.lblChapter.Text = "Chapter";
            // 
            // btnUpload
            // 
            this.btnUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.Location = new System.Drawing.Point(226, 3);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(135, 29);
            this.btnUpload.TabIndex = 18;
            this.btnUpload.Text = "Upload New Topic";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // cmbChapters
            // 
            this.cmbChapters.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbChapters.FormattingEnabled = true;
            this.cmbChapters.Items.AddRange(new object[] {
            "--Select the Chapter--"});
            this.cmbChapters.Location = new System.Drawing.Point(63, 46);
            this.cmbChapters.Name = "cmbChapters";
            this.cmbChapters.Size = new System.Drawing.Size(298, 23);
            this.cmbChapters.TabIndex = 19;
            this.cmbChapters.SelectedIndexChanged += new System.EventHandler(this.cmbChapters_SelectedIndexChanged);
            // 
            // btnToc
            // 
            this.btnToc.Enabled = false;
            this.btnToc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnToc.Location = new System.Drawing.Point(8, 3);
            this.btnToc.Name = "btnToc";
            this.btnToc.Size = new System.Drawing.Size(157, 30);
            this.btnToc.TabIndex = 18;
            this.btnToc.Text = "Table of Contents";
            this.btnToc.UseVisualStyleBackColor = true;
            // 
            // pnlProgressBar
            // 
            this.pnlProgressBar.Controls.Add(this.rtbProgress);
            this.pnlProgressBar.Controls.Add(this.pbar);
            this.pnlProgressBar.Location = new System.Drawing.Point(2, 599);
            this.pnlProgressBar.Name = "pnlProgressBar";
            this.pnlProgressBar.Size = new System.Drawing.Size(359, 68);
            this.pnlProgressBar.TabIndex = 8;
            // 
            // rtbProgress
            // 
            this.rtbProgress.Enabled = false;
            this.rtbProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbProgress.Location = new System.Drawing.Point(6, 3);
            this.rtbProgress.Name = "rtbProgress";
            this.rtbProgress.Size = new System.Drawing.Size(349, 41);
            this.rtbProgress.TabIndex = 1;
            this.rtbProgress.Text = "";
            // 
            // pbar
            // 
            this.pbar.Location = new System.Drawing.Point(35, 45);
            this.pbar.Name = "pbar";
            this.pbar.Size = new System.Drawing.Size(285, 23);
            this.pbar.TabIndex = 0;
            // 
            // dGV_topics
            // 
            this.dGV_topics.AllowUserToAddRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkGray;
            this.dGV_topics.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dGV_topics.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dGV_topics.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dGV_topics.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGV_topics.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dGV_topics.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_topics.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGV_topics.DefaultCellStyle = dataGridViewCellStyle3;
            this.dGV_topics.Location = new System.Drawing.Point(3, 75);
            this.dGV_topics.Name = "dGV_topics";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dGV_topics.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dGV_topics.RowHeadersVisible = false;
            this.dGV_topics.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dGV_topics.Size = new System.Drawing.Size(358, 518);
            this.dGV_topics.TabIndex = 0;
            this.dGV_topics.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGV_topics_CellContentClick_1);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // iBaTs_TutoringSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1057, 692);
            this.Controls.Add(this.splt_syllabus);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1073, 730);
            this.MinimumSize = new System.Drawing.Size(1073, 726);
            this.Name = "iBaTs_TutoringSystem";
            this.Text = "iBaTs_TutoringSystem";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.iBaTs_TutoringSystem_FormClosing);
            this.Load += new System.EventHandler(this.sys_Main_Load);
            this.splt_syllabus.Panel1.ResumeLayout(false);
            this.splt_syllabus.Panel2.ResumeLayout(false);
            this.splt_syllabus.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splt_syllabus)).EndInit();
            this.splt_syllabus.ResumeLayout(false);
            this.splt_bash.Panel1.ResumeLayout(false);
            this.splt_bash.Panel1.PerformLayout();
            this.splt_bash.Panel2.ResumeLayout(false);
            this.splt_bash.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splt_bash)).EndInit();
            this.splt_bash.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axAcroPDF1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axShockwaveFlash1)).EndInit();
            this.pnlProgressBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_topics)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splt_syllabus;
        private System.Windows.Forms.SplitContainer splt_bash;
        private System.Windows.Forms.DataGridView dGV_topics;
        private System.Windows.Forms.Label lblException;
        private System.Windows.Forms.Label lblTutoringSystem;
        private System.Windows.Forms.Label lblSyllabus;
        private System.Windows.Forms.TextBox txtTopic;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.RichTextBox txtPPTFilePath;
        private System.Windows.Forms.Label lblPPTFileUpload;
        private System.Windows.Forms.Panel pnlProgressBar;
        private System.Windows.Forms.ProgressBar pbar;
        private System.Windows.Forms.TextBox txtVideoURL;
        private System.Windows.Forms.Label lblVideoURL;
        private AxShockwaveFlashObjects.AxShockwaveFlash axShockwaveFlash1;
        private System.Windows.Forms.RichTextBox txtQuizFilePath;
        private System.Windows.Forms.Label lblQuizFileUpload;
        private System.Windows.Forms.Button btnQuizBrowse;
        private System.Windows.Forms.RichTextBox rtbProgress;
        private System.Windows.Forms.Button btnChapterDisplay;
        private System.Windows.Forms.Button btnToc;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Label lblChapter;
        private System.Windows.Forms.ComboBox cmbChapters;
        private System.Windows.Forms.TextBox txtChapter;
        private System.Windows.Forms.Label lblUploadChapter;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private AxAcroPDFLib.AxAcroPDF axAcroPDF1;
        private System.Windows.Forms.RichTextBox rtbMaterial;
        private System.Windows.Forms.LinkLabel lnklblHome;
        private System.Windows.Forms.Button btnBashShell;
        private System.Windows.Forms.RadioButton rbword;
        private System.Windows.Forms.RadioButton rbtxt;
        private System.Windows.Forms.RadioButton rbPDF;
        private System.Windows.Forms.RadioButton rbppt;
        private System.Windows.Forms.Label lblTypeofMaterial;
    }
}

