﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tutoring_System.BLL;
using Microsoft.Office.Interop.PowerPoint;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.Word;



namespace Tutoring_System.UserInterface
{
    public partial class iBaTs_TutoringSystem : Form
    {
        Constants objConstants = new Constants();
        Progress objProgress = new Progress();
        /* for slideshow */
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern IntPtr FindWindow(string className, string windowtext);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
        /* for slideshow */
        /*for panel*/
        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, int uFlags);

        public static string XMLPath;
        private const int SWP_NOZORDER = 0x0004;
        private const int SWP_NOACTIVATE = 0x0010;
        private const int GWL_STYLE = -16;
        private const int WS_CAPTION = 0x00C00000;
        private const int WS_THICKFRAME = 0x00040000;

        /*for panel*/

        public iBaTs_TutoringSystem()
        {
            InitializeComponent();
        }
        private void OpenBash()
        {
            Process shell = new Process();
            try
            {
                shell.StartInfo.FileName = objConstants.fn_Shell;
                shell.StartInfo.Arguments = "--login -i";
                shell.Start();
                System.Threading.Thread.Sleep(100);
                SetParent(shell.MainWindowHandle, this.splt_bash.Panel2.Handle);
                SetWindowPos(shell.MainWindowHandle, IntPtr.Zero, 0, 0, (int)this.splt_bash.Panel2.ClientSize.Width, (int)this.splt_bash.Panel2.ClientSize.Height, SWP_NOZORDER | SWP_NOACTIVATE);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                shell.Dispose();   
            }
        }
        private void ReadSyllabus(string fn_Syllabus, bool coladd)
        {
            Syllabus objSyllabus = new Syllabus();
            System.Data.DataTable dt_chapters = objSyllabus.FillMainchapters(objConstants.fn_Chapters);
            cmbChapters.DataSource = dt_chapters.DefaultView;
            cmbChapters.DisplayMember = "Chapter";
            cmbChapters.ValueMember = "ChapterID";
            cmbChapters.BindingContext = this.BindingContext;
            DataGridViewLinkColumn lnktopiccol = new DataGridViewLinkColumn();
            DataGridViewLinkColumn lnktestcol = new DataGridViewLinkColumn(); // for adding test module
            DataGridViewLinkCell linktopic = new DataGridViewLinkCell();
            DataGridViewLinkCell linktest = new DataGridViewLinkCell();
            // for adding test module
            if (coladd)
            {
                dGV_topics.Columns.Add(lnktopiccol);
                dGV_topics.Columns.Add(lnktestcol);
            }// for adding test module
            lnktopiccol.HeaderText = "Sub Topic";
            lnktestcol.HeaderText = "Test";
            lnktestcol.FillWeight = 33;
            lnktopiccol.FillWeight = 67;
            // for adding test module
            LoadTopics(linktopic, linktest);
        }
        private void LoadTopics(DataGridViewLinkCell linktopic, DataGridViewLinkCell linktest)
        {
            rbppt.Visible = rbPDF.Visible = rbtxt.Visible = rbword.Visible = lblTypeofMaterial.Visible = false;
            rbppt.Checked = rbPDF.Checked = rbtxt.Checked = rbword.Checked = false;
            for (int i = 0; i <= dGV_topics.Rows.Count-1; i++)
            {
                dGV_topics.Rows.RemoveAt(i);
                i--;
                while (dGV_topics.Rows.Count == -1)
                    continue;
            }
            Syllabus objSyllabus = new Syllabus();
            System.Data.DataTable dt_syllabus = objSyllabus.FillSyllabusContents(objConstants.fn_Syllabus);
            try
            {
                lblException.Text = "Upload New Topic";
                foreach (DataRow dr in dt_syllabus.Rows)
                {
                    if (cmbChapters.SelectedValue.ToString() == dr["ChapterID"].ToString())
                    {
                        linktopic.Value = dr["Topic"].ToString();
                        if (dr["TestProgress"].ToString() == "Y")
                        {
                            int testminimum = Convert.ToInt32(Convert.ToDouble(dr["Score"].ToString()) / Convert.ToDouble(dr["Totalmarks"].ToString())) * 100;
                            if (testminimum < 50)
                                linktest.Value = dr["Test"].ToString() + " (Retake Test)";
                            else
                                linktest.Value = dr["Test"].ToString() + " (Attempted)";
                        }// for adding test module
                        else
                            linktest.Value = dr["Test"].ToString() + " (Not Attempted)";
                        linktopic.UseColumnTextForLinkValue = true;
                        linktest.UseColumnTextForLinkValue = true; 
                        // for adding test module 
                        //dGV_topics.Rows.Add(linktopic.Value);
                        dGV_topics.Rows.Add(linktopic.Value, linktest.Value); // for adding test module
                    }
                }
            }
            catch (Exception ex)
            {
                lblException.Visible = true;
                lblException.Text = ex.Message;
            }
            finally
            {
                dt_syllabus.Dispose();
                //lnktopiccol.Dispose();
                linktopic.Dispose();
                linktest.Dispose();
                objSyllabus = null;
            }
        }
        private void Openpptvideo(string topic, Microsoft.Office.Interop.PowerPoint.Application objApp)
        {
            Syllabus objSyllabus = new Syllabus();
            System.Data.DataTable dt_syllabus = objSyllabus.FillSyllabusContents(objConstants.fn_Syllabus);
            try
            {
                foreach (DataRow dr in dt_syllabus.Rows)
                {
                    if (topic == dr["Topic"].ToString())
                    {
                        objConstants.fn_Ppt = dr["PPTPath"].ToString();
                        objConstants.fn_Pdf = dr["PDFPath"].ToString();
                        objConstants.fn_Text = dr["TextPath"].ToString();
                        objConstants.fn_Word = dr["WordPath"].ToString();
                        objConstants.fn_Video = dr["VideoLinkPath"].ToString();
                        objConstants.fn_Testpath = dr["TestPath"].ToString();
                        dr["Progress"] = "Y";
                        btnChapterDisplay.Text = "Chapter " + dr["Topic"].ToString().Substring(0, 1);
                        lblTutoringSystem.Text =  dr["Topic"].ToString();
                    }
                }
                //string materialcode = objConstants.fn_Ppt.Split('.').Last();
                MessageBoxManager.Yes = "Video";
                MessageBoxManager.No = "Material";
                MessageBoxManager.Cancel = "Cancel";
                MessageBoxManager.Register();
                DialogResult dresult = MessageBox.Show("Select the mode of Tutorial", "Video", MessageBoxButtons.YesNoCancel);
                MessageBoxManager.Unregister();
                if (dresult == DialogResult.Yes || dresult == DialogResult.No)
                {
                    
                    objProgress.updateforprogress(objConstants.fn_Syllabus, dt_syllabus);   
                }
                if (dresult == DialogResult.Yes)
                {
                    lblTutoringSystem.Visible = false;
                    objApp.Quit();//quits the presentation
                    axAcroPDF1.Dispose();
                    rtbMaterial.Visible = false;
                    axAcroPDF1.Visible = false;
                    axShockwaveFlash1.Dispose();
                    axShockwaveFlash1 = new AxShockwaveFlashObjects.AxShockwaveFlash();
                    axShockwaveFlash1.Dock = DockStyle.Fill;
                    splt_bash.Panel1.Controls.Add(axShockwaveFlash1);
                    axShockwaveFlash1.Visible = true;
                    axShockwaveFlash1.Movie = objConstants.fn_Video;
                    //btnChapterDisplay.Visible = true;
                    /*For opening video*/
                }
                else if (dresult == DialogResult.No)
                {
                    rtbMaterial.Visible = false;
                    objApp.Quit();
                    axShockwaveFlash1.Dispose();
                    axAcroPDF1.Dispose(); 
                    btnChapterDisplay.Visible = false;
                    lblTutoringSystem.Visible = true;
                    lblTypeofMaterial.Visible = true;
                    if (objConstants.fn_Ppt != "")
                        rbppt.Visible = true;
                    if (objConstants.fn_Pdf != "")
                        rbPDF.Visible = true;
                    if (objConstants.fn_Text != "")
                        rbtxt.Visible = true;
                    if (objConstants.fn_Word != "")
                        rbword.Visible = true;
                    axAcroPDF1 = new AxAcroPDFLib.AxAcroPDF();
                }
                else
                {
                    lblTutoringSystem.Text = "iBaTs Tutoring System";
                }
            }
            catch (Exception ex)
            {
                lblException.Visible = true;
                lblException.Text = ex.Message;
            }
            finally
            {
                dt_syllabus.Dispose();
                objSyllabus = null;
                if (objApp != null) Marshal.ReleaseComObject(objApp);
            }
        }
        private void sys_Main_Load(object sender, EventArgs e)
        {
            ReadSyllabus(objConstants.fn_Syllabus, true);
            CalculateProgress();
            lblTutoringSystem.Text = "iBaTs Tutoring System";
            lblTutoringSystem.Visible = true;
            OpenBash();
        }
        private void CalculateProgress()
        {
            Syllabus objSyllabus = new Syllabus();
            System.Data.DataTable dt_syllabus = null;
            int chaptercount = 0; int score = 0;
            int excercisecount = 0;
            int totalmarks = 0; 
            pbar.Maximum = 100;
            try
            {
                dt_syllabus = objSyllabus.FillSyllabusContents(objConstants.fn_Syllabus);
                foreach (DataRow dr in dt_syllabus.Rows)
                {
                    if (dr["Progress"].ToString() == "Y") 
                        chaptercount++;

                    if (dr["TestProgress"].ToString() == "Y")
                        excercisecount++;
                        score += Convert.ToInt32(dr["Score"].ToString());
                        totalmarks += Convert.ToInt32(dr["Totalmarks"].ToString());
                }
                int chapterprogress = (Int32)(((chaptercount * 100) / dt_syllabus.Rows.Count));
                int excerciseprogress = (Int32)(((excercisecount * 100) / dt_syllabus.Rows.Count));
                rtbProgress.Text = "You have completed " + chapterprogress.ToString() + "% of all chapters and "
                    + excerciseprogress.ToString() + "% of all excercises. " + "You secured " + score.ToString() + " points out of " + totalmarks.ToString() + " points." ;
                pbar.Value = excerciseprogress;
                //pbar.CreateGraphics().DrawString(progress.ToString() + "%", new System.Drawing.Font("Arial", (float)10.25, FontStyle.Bold), Brushes.IndianRed, new PointF(pbar.Width / 2 - 10, pbar.Height / 2 - 7));

            }
            catch (Exception ex)
            {
                lblException.Text = ex.Message;
            }
            finally
            {
                dt_syllabus.Dispose();
                objSyllabus = null;
            }
        }
        private void RefreshGrid(int p)
        {
            if (p == 0)
            {
                for (int i = 0; i < dGV_topics.Rows.Count - 1; i++)
                {
                    dGV_topics.Rows.RemoveAt(i);
                    i--;
                    while (dGV_topics.Rows.Count == 0)
                        continue;
                }
                ReadSyllabus(objConstants.fn_Syllabus, false);
            }
        }
        private void btnBashShell_Click(object sender, EventArgs e)
        {
            OpenBash();
        }
        private void dGV_topics_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            String topic = null;
            String test = null;
            btnChapterDisplay.Visible = false;
            lblException.Visible = lblUploadChapter.Visible = lblSyllabus.Visible = lblVideoURL.Visible =
            lblPPTFileUpload.Visible = lblQuizFileUpload.Visible = txtChapter.Visible = txtTopic.Visible = txtPPTFilePath.Visible =
            txtQuizFilePath.Visible = txtVideoURL.Visible = btnBrowse.Visible = btnQuizBrowse.Visible = btnSave.Visible = false;
            rbppt.Visible = rbPDF.Visible = rbtxt.Visible = rbword.Visible = lblTypeofMaterial.Visible = false;
            rbppt.Checked = rbPDF.Checked = rbtxt.Checked = rbword.Checked = false;
            Microsoft.Office.Interop.PowerPoint.Application objApp = new Microsoft.Office.Interop.PowerPoint.Application();
            /*Code to open the tutorial start*/
            if (e.ColumnIndex == 0)
            {
                topic = (dGV_topics.Rows[e.RowIndex].Cells[e.ColumnIndex].Value).ToString();
                if (topic != null)
                {
                    try
                    {
                        Openpptvideo(topic, objApp);
                        /*to update progress*/
                        CalculateProgress();
                        /*to update progress*/
                    }
                    catch (Exception ex)
                    {
                        lblException.Visible = true;
                        lblException.Text = ex.Message;
                    }
                    finally
                    {

                    }
                }

            }

            /*Code to open the tutorial end*/

            /*Code to open the test start*/
            else if (e.ColumnIndex == 1)
            {
                string s = (dGV_topics.Rows[e.RowIndex].Cells[e.ColumnIndex].Value).ToString();
                test = (s.Substring(0, s.IndexOf('('))).TrimEnd();
                //for removing attempted and non-attempted
                Syllabus objSyllabus = new Syllabus();
                System.Data.DataTable dt_syllabus = objSyllabus.FillSyllabusContents(objConstants.fn_Syllabus);
                if (test != null)
                {
                    try
                    {
                        foreach (DataRow dr in dt_syllabus.Rows)
                        {
                            if (test == dr["Test"].ToString() && cmbChapters.SelectedValue.ToString() == dr["ChapterID"].ToString())
                            {
                                btnChapterDisplay.Text = "Chapter " + dr["Topic"].ToString().Substring(0, 1);
                                if (dr["Progress"].ToString() == "Y")
                                {
                                    
                                    objConstants.fn_Testpath = dr["TestPath"].ToString();
                                    objConstants.randqs = dr["Randqs"].ToString();
                                    objConstants.selectedtopic = dr["Topic"].ToString();
                                    lblTutoringSystem.Text = "Test on " + dr["Topic"].ToString();
                                    //btnChapterDisplay.Visible = true;
                                    //rtbMaterial.Visible = axAcroPDF1.Visible = axShockwaveFlash1.Visible = false;
                                    //axShockwaveFlash1.Dispose();
                                    //axAcroPDF1.Dispose();
                                    //objApp.Quit();
                                    //lblTutoringSystem.Visible = btnTest.Visible = true;
                                    //btnTest.Text = "Start the Test";
                                    //btnSubmit.Text = "Submit";
                                    CalculateProgress();                                    
                                    this.Hide();
                                    Test Test = new Test(objConstants.selectedtopic, objConstants.fn_Testpath, objConstants.randqs);
                                    Test.Show();
                                }
                                else
                                {
                                    DialogResult dresult = MessageBox.Show("Would like to proceed without going through tutoring material?", "Video", MessageBoxButtons.YesNoCancel);
                                    if (dresult == DialogResult.Yes)
                                    {
                                        //btnChapterDisplay.Visible = true;
                                        //btnTest.Text = "Start the Test";
                                        //btnSubmit.Text = "Submit";
                                        //rtbMaterial.Visible = axShockwaveFlash1.Visible = axAcroPDF1.Visible = false;
                                        //axShockwaveFlash1.Dispose();
                                        //axAcroPDF1.Dispose();
                                        //objApp.Quit();
                                        objConstants.fn_Testpath = dr["TestPath"].ToString();
                                        lblTutoringSystem.Text = "Test on " + dr["Topic"].ToString();
                                        lblTutoringSystem.Visible = true;
                                        /*For progress if lesson is not read and test is attempted*/
                                        objConstants.selectedtopic = dr["Topic"].ToString();
                                        CalculateProgress();
                                        /*For progress if lesson is not read and test is attempted*/
                                        this.Hide();
                                        Test Test = new Test(lblTutoringSystem.Text, objConstants.fn_Testpath, objConstants.randqs);
                                        Test.Show();
                                    }
                                    else if (dresult == DialogResult.No)
                                    {
                                        lblTutoringSystem.Visible = false;
                                        Openpptvideo(dr["Topic"].ToString(), objApp);
                                    }
                                    else
                                    {

                                    }
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        lblException.Visible = true;
                        lblException.Text = ex.Message;
                    }
                }
            }
            /*Code to open the test end*/
        }
        private void cmbChapters_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataGridViewLinkCell linktopic = new DataGridViewLinkCell();
            DataGridViewLinkCell linktest = new DataGridViewLinkCell();
            LoadTopics(linktopic, linktest);
        }
        private void btnUpload_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormController.ShowForm("Upload");
        }
        private void lnklblHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FormController.ShowForm("Home");
        }

        private void rbppt_CheckedChanged(object sender, EventArgs e)
        {
            lblTutoringSystem.Visible = false; rbppt.Visible = rbPDF.Visible = rbtxt.Visible = rbword.Visible = lblTypeofMaterial.Visible = false;
            rbppt.Checked = rbPDF.Checked = rbtxt.Checked= rbword.Checked = false;
            Microsoft.Office.Interop.PowerPoint.Application objApp = new Microsoft.Office.Interop.PowerPoint.Application();
            Presentations objPresSet = objApp.Presentations;
            Presentation objPres = objPresSet.Open(Path.GetFullPath(objConstants.fn_Ppt), MsoTriState.msoFalse, MsoTriState.msoTrue, MsoTriState.msoFalse);
            SlideShowSettings objSSS = objPres.SlideShowSettings;
            objSSS.ShowType = Microsoft.Office.Interop.PowerPoint.PpSlideShowType.ppShowTypeSpeaker;
            objSSS.LoopUntilStopped = MsoTriState.msoTrue;
            objSSS.Run();
            WindowWrapper handlewrapper = new WindowWrapper((IntPtr)objPres.SlideShowWindow.HWND);
            SetParent(handlewrapper.Handle, this.splt_bash.Panel1.Handle);
            SetWindowPos(handlewrapper.Handle, IntPtr.Zero, 0, 0, (int)this.splt_bash.Panel1.ClientSize.Width, (int)this.splt_bash.Panel1.ClientSize.Height, SWP_NOZORDER | SWP_NOACTIVATE);
            /*For opening Presentation*/
            //objApp = null;
            objPresSet = null;
            objPres = null;
            objSSS = null;
            handlewrapper = null;
            GC.Collect();
        }

        private void rbtxt_CheckedChanged(object sender, EventArgs e)
        {
            lblTutoringSystem.Visible = false; rbppt.Visible = rbPDF.Visible = rbtxt.Visible = rbword.Visible = lblTypeofMaterial.Visible = false;
            rbppt.Checked = rbPDF.Checked = rbtxt.Checked = rbword.Checked = false;
            rtbMaterial.Clear();
            SetWindowPos(rtbMaterial.Handle, IntPtr.Zero, 0, 0, (int)this.splt_bash.Panel1.ClientSize.Width, (int)this.splt_bash.Panel1.ClientSize.Height, SWP_NOZORDER | SWP_NOACTIVATE);
            string filename = objConstants.fn_Text;
            foreach (string line in File.ReadLines(filename))
            {
                string text = line;
                this.BeginInvoke(new Action(() => rtbMaterial.AppendText(text + "\n")));
            }
            rtbMaterial.Visible = true;
            rtbMaterial.ReadOnly = true;
        }

        private void rbPDF_CheckedChanged(object sender, EventArgs e)
        {
            lblTutoringSystem.Visible = false; rbppt.Visible = rbPDF.Visible = rbtxt.Visible = rbword.Visible = lblTypeofMaterial.Visible = false;
            rbppt.Checked = rbPDF.Checked = rbtxt.Checked = rbword.Checked = false;
            axAcroPDF1.Dock = DockStyle.Fill;
            splt_bash.Panel1.Controls.Add(axAcroPDF1);
            axAcroPDF1.setShowToolbar(false);
            axAcroPDF1.Visible = true;
            axAcroPDF1.LoadFile(objConstants.fn_Pdf);
            axAcroPDF1.Show();
        }

        private void rbword_CheckedChanged(object sender, EventArgs e)
        {
            lblTutoringSystem.Visible = false; rbppt.Visible = rbPDF.Visible = rbtxt.Visible = rbword.Visible = lblTypeofMaterial.Visible = false;
            rbppt.Checked = rbPDF.Checked = rbtxt.Checked = rbword.Checked = false;
           
            rtbMaterial.Clear();
            SetWindowPos(rtbMaterial.Handle, IntPtr.Zero, 0, 0, (int)this.splt_bash.Panel1.ClientSize.Width, (int)this.splt_bash.Panel1.ClientSize.Height, SWP_NOZORDER | SWP_NOACTIVATE);
            object m = System.Reflection.Missing.Value;
            object readOnly = (object)true;
            var wordapp = new Microsoft.Office.Interop.Word.Application();
            Document document = wordapp.Documents.Open(Path.GetFullPath(objConstants.fn_Word), ref m, ref readOnly,
            ref m, ref m, ref m, ref m, ref m, ref m, ref m,
            ref m, ref m, ref m, ref m, ref m, ref m);
            document.ActiveWindow.Selection.WholeStory();
            document.ActiveWindow.Selection.Copy();
            IDataObject data = Clipboard.GetDataObject();
            rtbMaterial.Rtf = data.GetData(DataFormats.Rtf).ToString();
            rtbMaterial.Visible = true;
            document.Close(ref m, ref m, ref m);
        }

        private void iBaTs_TutoringSystem_FormClosing(object sender, FormClosingEventArgs e)
        {
                if (MessageBox.Show("Do you want to close the tutorial?", "Tutoring System",
                   MessageBoxButtons.YesNo) == DialogResult.No)
                {
                    e.Cancel = true;
                }
                foreach (Process p in Process.GetProcesses())
                {
                    if (p.ProcessName == "sh")
                    {
                        p.Kill();
                    }
                }
        }
        
    }

}
